document.querySelectorAll('.navlinks a').forEach(link=>{
  link.addEventListener('click',()=>window.scrollTo({top:document.querySelector(link.getAttribute('href')).offsetTop-60,behavior:'smooth'}));
});
